import React, { useState, useEffect } from "react";
import "./CurrencyConverter.css";

const CurrencyConverter = () => {
  const [amount, setAmount] = useState(1);
  const [fromCurrency, setFromCurrency] = useState("USD");
  const [toCurrency, setToCurrency] = useState("INR");
  const [exchangeRate, setExchangeRate] = useState(0);
  const [convertedAmount, setConvertedAmount] = useState(0);

  useEffect(() => {
    fetch(`https://api.exchangerate-api.com/v4/latest/${fromCurrency}`)
      .then((res) => res.json())
      .then((data) => {
        const rate = data.rates[toCurrency];
        setExchangeRate(rate);
      });
  }, [fromCurrency, toCurrency, amount]);

  return (
    <div className="converter-container">
      <h1>Realtime Currency Converter</h1>
      <img
        src="https://cdn-icons-png.flaticon.com/512/10826/10826388.png"
        alt="Currency"
        className="currency-icon"
      />
      <input
        type="number"
        min="0.0"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
      />
      <div className="currency-selectors">
        <select
          value={fromCurrency}
          onChange={(e) => setFromCurrency(e.target.value)}
        >
          <option value="USD">USD</option>
          <option value="INR">INR</option>
          <option value="EUR">EUR</option>
        </select>
        <span>➜</span>
        <select
          value={toCurrency}
          onChange={(e) => setToCurrency(e.target.value)}
        >
          <option value="INR">INR</option>
          <option value="USD">USD</option>
          <option value="EUR">EUR</option>
        </select>
      </div>
      <p>
        1 {fromCurrency} = {exchangeRate} {toCurrency}
      </p>
      <button onClick = {() => setConvertedAmount((amount * exchangeRate).toFixed(2))}>Convert</button>
      
      <div className="result">
        {amount} {fromCurrency}
      </div>
      <div className="result">
        {convertedAmount} {toCurrency}
      </div>
    </div>
  );
};

export default CurrencyConverter;
