import React from "react";
import CurrencyConverter from "./CurrencyConverter";

function App() {
  return <CurrencyConverter />;
}

export default App;
