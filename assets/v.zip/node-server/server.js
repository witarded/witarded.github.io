const http = require('http');
const url = require('url');
const fs = require('fs');
const path = require('path');

const PORT = 3000;

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true); // `true` to parse query string
  const query = parsedUrl.query;
  const method = req.method;

  let filePath = '';

  switch (method) {
    case 'GET':
      filePath = path.join(__dirname, 'responses', 'get.json');
      break;
    case 'POST':
      filePath = path.join(__dirname, 'responses', 'post.json');
      break;
    case 'PUT':
      filePath = path.join(__dirname, 'responses', 'put.json');
      break;
    case 'DELETE':
      filePath = path.join(__dirname, 'responses', 'delete.json');
      break;
    default:
      res.writeHead(405, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ message: 'Method Not Allowed' }));
  }

  // Collect request body
  let body = '';
  req.on('data', chunk => {
    body += chunk.toString();
  });

  req.on('end', () => {
    let parsedBody;
    try {
      parsedBody = body ? JSON.parse(body) : {};
    } catch (err) {
      parsedBody = { error: 'Invalid JSON body' };
    }

    fs.readFile(filePath, 'utf8', (err, data) => {
      if (err) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: 'Internal Server Error' }));
      }

      let fileData = {};
      try {
        fileData = JSON.parse(data);
      } catch (e) {
        fileData = { error: 'Invalid JSON file content' };
      }

      const responseData = {
        method,
        query,
        requestBody: parsedBody,
        responseFromFile: fileData
      };

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(responseData, null, 2));
    });
  });
});

server.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
